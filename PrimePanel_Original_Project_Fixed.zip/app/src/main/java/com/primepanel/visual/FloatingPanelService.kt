package com.primepanel.visual

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.math.max

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var minimized = false
    private val purple = Color.rgb(139, 75, 245)
    private val panelBg = Color.rgb(15, 15, 19)
    private val cardBg = Color.rgb(29, 27, 34)
    private val muted = Color.rgb(174, 166, 187)
    private var params: WindowManager.LayoutParams? = null
    private var body: LinearLayout? = null
    private var activeTab = "MAIN"

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 13f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(7), dp(8), dp(7))
        }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(9), dp(7), dp(9), dp(7))
        setBackgroundColor(cardBg)
        val p = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
        layoutParams = p
    }
    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panelBg)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(panelBg); cornerRadius = dp(13).toFloat()
                setStroke(dp(1), 0xFF55416F.toInt())
            }
            clipToOutline = true
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(5), dp(7), dp(5))
            setBackgroundColor(0xFF21182E.toInt())
        }
        val dragHandle = text("✦  PRIME PANEL", 15f, Color.WHITE, true)
        header.addView(dragHandle, LinearLayout.LayoutParams(0, -2, 1f))
        val search = text("⌕", 21f, 0xFFD8C5F7.toInt())
        header.addView(search)
        val min = Button(this).apply {
            text = "—"; textSize = 12f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF51327B.toInt())
            setOnClickListener { toggleMinimize(root) }
        }
        header.addView(min, LinearLayout.LayoutParams(dp(42), dp(38)))
        val close = Button(this).apply {
            text = "×"; textSize = 18f; setTextColor(Color.WHITE)
            setBackgroundColor(0xFF51327B.toInt())
            setOnClickListener { stopSelf() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(38), dp(38)))
        root.addView(header)
        dragHandle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var x = 0; var y = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = params ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; x=p.x; y=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x=x+(e.rawX-sx).toInt(); p.y=y+(e.rawY-sy).toInt(); wm.updateViewLayout(root,p); return true }
                }
                return false
            }
        })
        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(5), dp(7), dp(5), dp(5))
            setBackgroundColor(0xFF111015.toInt())
        }
        val contentScroll = ScrollView(this)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(9), dp(9), dp(9), dp(9))
        }
        contentScroll.addView(body)
        val names = listOf("MAIN", "AIM", "ESP", "VISUALS", "PLAYER", "EXTRA", "SETTINGS")
        names.forEach { name ->
            val b = TextView(this).apply {
                text = name; textSize = 11f; gravity = Gravity.CENTER
                setTextColor(if (name == activeTab) Color.WHITE else muted)
                setPadding(dp(3), dp(13), dp(3), dp(13))
                setBackgroundColor(if (name == activeTab) 0xFF38234F.toInt() else Color.TRANSPARENT)
                setOnClickListener { activeTab = name; refreshBody(); 
                    for (i in 0 until nav.childCount) {
                        val child = nav.getChildAt(i) as TextView
                        child.setTextColor(if (child.text == activeTab) Color.WHITE else muted)
                        child.setBackgroundColor(if (child.text == activeTab) 0xFF38234F.toInt() else Color.TRANSPARENT)
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(-1, dp(43)))
        }
        main.addView(nav, LinearLayout.LayoutParams(dp(82), -1))
        main.addView(contentScroll, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(main, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("PRIME PANEL  •  VISUAL SIMULATOR ONLY  •  v0.2.0", 9f, muted).apply { gravity=Gravity.CENTER })
        val w = dp(350); val h = dp(510)
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER; x=0; y=0 }
        panel = root
        wm.addView(root, params)
        refreshBody()
    }
    private fun toggleMinimize(root: View) {
        val p = params ?: return
        if (!minimized) {
            p.width = dp(190); p.height = dp(48); minimized = true
            root.findViewWithTag<View>("body")?.visibility = View.GONE
            // Keep a compact draggable header; hide all content below it.
            if (root is LinearLayout && root.childCount > 1) {
                for (i in 1 until root.childCount) root.getChildAt(i).visibility = View.GONE
            }
        } else {
            p.width = dp(350); p.height = dp(510); minimized = false
            if (root is LinearLayout && root.childCount > 1) {
                for (i in 1 until root.childCount) root.getChildAt(i).visibility = View.VISIBLE
            }
        }
        wm.updateViewLayout(root, p)
    }
    private fun refreshBody() {
        val b = body ?: return
        b.removeAllViews()
        b.addView(text(activeTab, 19f, 0xFFDCC8FF.toInt(), true))
        when (activeTab) {
            "MAIN" -> {
                addCard("WELCOME TO PRIME PANEL", "Original purple control center\nAll controls below are local visual demos.")
                addCard("QUICK STATUS", "Panel: ACTIVE\nSimulator: READY\nGame connection: NONE")
            }
            "AIM" -> {
                addCard("AIM ASSIST DEMO", "Visual-only controls; they do not aim or interact with a game.")
                toggle("Aim Assist Preview", true); slider("FOV Preview", 10, 100, 65)
                slider("Smoothness Preview", 1, 100, 55); toggle("Show FOV Circle", true)
                toggle("Target Marker Animation", false)
            }
            "ESP" -> {
                addCard("SQUARE ESP PREVIEW", "Example targets are generated inside this panel only.")
                b.addView(EspPreview(this).apply { layoutParams=LinearLayout.LayoutParams(-1, dp(170)) })
                toggle("Square Box Preview", true); toggle("Name Labels", true)
                toggle("Distance Labels", true); toggle("Health Bars", true)
            }
            "VISUALS" -> {
                addCard("VISUAL CONTROLS", "Customize the panel's own preview.")
                toggle("Neon Border", true); toggle("Animated Accents", true)
                toggle("Crosshair Preview", false); slider("Preview Brightness", 0, 100, 70)
            }
            "PLAYER" -> {
                addCard("SIMULATED PLAYER", "Name: Demo Player\nStatus: Training Preview\nCoordinates: Local Canvas")
                slider("Demo Health", 0, 100, 82); slider("Demo Shield", 0, 100, 60)
            }
            "EXTRA" -> {
                addCard("EXTRA TOOLS", "Standalone interface utilities.")
                toggle("Compact Mode Preview", false); toggle("Show FPS Counter Demo", true)
                toggle("Show Status Badge", true)
            }
            "SETTINGS" -> {
                addCard("PANEL SETTINGS", "Changes affect this panel only.")
                toggle("Purple Theme", true); toggle("Keep Panel Open", false)
                addCard("ABOUT", "PRIME PANEL\nVersion 0.2.0\nIndependent visual simulator")
            }
        }
    }
    private fun addCard(title: String, desc: String) {
        val c=card(); c.addView(text(title, 12f, 0xFFDCC8FF.toInt(), true))
        c.addView(text(desc, 11f, muted)); body?.addView(c)
    }
    private fun toggle(label: String, initial: Boolean) {
        val row=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; setPadding(dp(5),dp(3),dp(5),dp(3)) }
        row.addView(text(label, 12f, Color.WHITE), LinearLayout.LayoutParams(0,-2,1f))
        val sw=Switch(this).apply { isChecked=initial; buttonTintList=null; thumbTintList=android.content.res.ColorStateList.valueOf(Color.WHITE)
            trackTintList=android.content.res.ColorStateList.valueOf(if(initial) purple else 0xFF55515C.toInt()) }
        row.addView(sw); body?.addView(row)
        body?.addView(View(this).apply { setBackgroundColor(0xFF302B36.toInt()) }, LinearLayout.LayoutParams(-1,dp(1)))
    }
    private fun slider(label: String, min: Int, max: Int, value: Int) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(5),dp(5),dp(5),dp(5)) }
        val labelView=text("$label  •  $value", 11f, Color.WHITE)
        box.addView(labelView)
        val seek=SeekBar(this).apply { this.max=max-min; progress=value-min; progressTintList=android.content.res.ColorStateList.valueOf(purple); thumbTintList=android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { labelView.text="$label  •  ${p+min}" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(seek); body?.addView(box)
    }
    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel=null; super.onDestroy()
    }
}

private class EspPreview(context: android.content.Context) : View(context) {
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val purple = Color.rgb(157, 104, 255)
    override fun onDraw(c: android.graphics.Canvas) {
        super.onDraw(c)
        c.drawColor(0xFF100D15.toInt())
        p.style=android.graphics.Paint.Style.STROKE; p.strokeWidth=dp(2f); p.color=purple
        c.drawRoundRect(dp(35f),dp(20f),dp(105f),dp(135f),dp(4f),dp(4f),p)
        c.drawRoundRect(dp(155f),dp(42f),dp(225f),dp(145f),dp(4f),dp(4f),p)
        p.style=android.graphics.Paint.Style.FILL; p.textSize=dp(10f); p.color=Color.WHITE
        c.drawText("DEMO 01",dp(35f),dp(14f),p); c.drawText("DEMO 02",dp(155f),dp(36f),p)
        p.color=0xFF55D68B.toInt()
        c.drawRect(dp(35f),dp(139f),dp(92f),dp(143f),p)
        c.drawRect(dp(155f),dp(149f),dp(205f),dp(153f),p)
    }
    private fun dp(v: Float) = v * resources.displayMetrics.density
}
