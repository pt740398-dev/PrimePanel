package com.primepanel.visual

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 13, 17)
    private val purple = Color.rgb(139, 75, 245)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "✦  PRIME PANEL"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "PURPLE CONTROL CENTER  •  VERSION 0.2.0"
            textSize = 11f; setTextColor(0xFFB99BEF.toInt())
            setPadding(0, 8, 0, 28)
        })
        val card = TextView(this).apply {
            text = "A custom floating control panel with separate sections, interactive demo switches, sliders and an ESP-style visual simulator. It does not connect to or modify any game."
            textSize = 15f; setTextColor(Color.LTGRAY)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF21182E.toInt())
        }
        root.addView(card)
        val launch = Button(this).apply {
            text = "OPEN FLOATING PANEL"
            setTextColor(Color.WHITE)
            setBackgroundColor(purple)
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                    Toast.makeText(this@MainActivity, "Prime Panel started", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val lp = LinearLayout.LayoutParams(-1, 58).apply { topMargin = 24 }
        root.addView(launch, lp)
        root.addView(TextView(this).apply {
            text = "Tip: allow 'Display over other apps', return here, then tap OPEN FLOATING PANEL."
            textSize = 13f; setTextColor(0xFFAAA4B4.toInt()); setPadding(0, 18, 0, 0)
        })
        setContentView(root)
    }
}
