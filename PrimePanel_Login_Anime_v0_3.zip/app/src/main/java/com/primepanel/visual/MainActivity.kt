package com.primepanel.visual

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val purple = Color.rgb(145, 48, 255)
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var message: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int = 0xFF7724C9.toInt()) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(16).toFloat(); setStroke(dp(1), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 5, 15)
        window.navigationBarColor = Color.rgb(8, 5, 15)
        buildLogin()
    }

    private fun buildLogin() {
        val frame = FrameLayout(this)
        val wallpaper = ImageView(this).apply {
            setImageResource(R.drawable.anime_wallpaper)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        frame.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        frame.addView(View(this).apply { setBackgroundColor(0xB9000010.toInt()) }, FrameLayout.LayoutParams(-1, -1))

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(25), dp(36), dp(25), dp(28))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.prime_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Prime Panel logo"
        }
        content.addView(logo, LinearLayout.LayoutParams(dp(174), dp(174)).apply { bottomMargin = dp(8) })
        content.addView(TextView(this).apply {
            text = "LOGIN TO CONTINUE"; textSize = 21f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        content.addView(TextView(this).apply {
            text = "Enter your Prime Panel credentials"; textSize = 12f
            setTextColor(0xFFD7C4F4.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(22))
        })
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(0xE90B0714.toInt())
        }
        username = EditText(this).apply {
            hint = "Username"; setSingleLine(true); setTextColor(Color.WHITE)
            setHintTextColor(0xFFBCA9D2.toInt()); textSize = 15f
            setPadding(dp(14), 0, dp(14), 0); background = rounded(0xFF171020.toInt())
            setCompoundDrawablePadding(dp(8))
        }
        card.addView(username, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(12) })
        password = EditText(this).apply {
            hint = "Password"; setSingleLine(true); inputType = 129
            setTextColor(Color.WHITE); setHintTextColor(0xFFBCA9D2.toInt()); textSize = 15f
            setPadding(dp(14), 0, dp(14), 0); background = rounded(0xFF171020.toInt())
        }
        card.addView(password, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(15) })
        val login = Button(this).apply {
            text = "LOGIN  →"; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); background = rounded(purple, 0xFFB46CFF.toInt())
            setOnClickListener { attemptLogin() }
        }
        card.addView(login, LinearLayout.LayoutParams(-1, dp(54)))
        message = TextView(this).apply {
            text = "DEMO ACCESS  •  VISUAL SIMULATOR ONLY"
            textSize = 10f; setTextColor(0xFFD8B9FF.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(17), 0, 0)
        }
        card.addView(message)
        content.addView(card, LinearLayout.LayoutParams(-1, -2))
        content.addView(TextView(this).apply {
            text = "PRIME PANEL  •  VERSION 0.3.0"; textSize = 10f
            setTextColor(0xFFD1B4F5.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        })
        scroll.addView(content)
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    private fun attemptLogin() {
        if (username.text.toString().trim() != "prime" || password.text.toString() != "1") {
            message.text = "Incorrect username or password"
            message.setTextColor(0xFFFF7A91.toInt())
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            message.text = "Allow Display over other apps, then tap LOGIN again."
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, FloatingPanelService::class.java))
        Toast.makeText(this, "Welcome to Prime Panel", Toast.LENGTH_SHORT).show()
        finish()
    }
}
