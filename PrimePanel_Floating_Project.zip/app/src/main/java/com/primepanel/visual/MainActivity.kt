package com.primepanel.visual

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(15, 15, 20))
        }
        val title = TextView(this).apply {
            text = "PRIME PANEL"
            textSize = 28f
            setTextColor(Color.rgb(255, 65, 75))
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Floating visual demo only\nNo game interaction or cheats."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }
        val start = Button(this).apply {
            text = "ENABLE FLOATING PANEL"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                    finish()
                }
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(start)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        // User can tap the enable button again after granting overlay permission.
    }
}
