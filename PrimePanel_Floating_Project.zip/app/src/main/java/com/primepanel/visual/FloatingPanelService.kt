package com.primepanel.visual

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun bg(color: Int, stroke: Int = Color.rgb(255, 45, 65)): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = 24f; setStroke(2, stroke)
        }

    private fun label(text: String, size: Float = 14f): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
            setPadding(18, 12, 18, 12)
        }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(Color.rgb(18, 18, 24))
            setPadding(12, 10, 12, 12)
            alpha = 0f
            scaleX = 0.88f; scaleY = 0.88f
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = label("✦ PRIME PANEL", 17f).apply {
            setTextColor(Color.rgb(255, 65, 80))
            typeface = Typeface.DEFAULT_BOLD
        }
        val close = label("—", 20f).apply {
            gravity = Gravity.CENTER
            setOnClickListener { togglePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(close)
        root.addView(header)

        val subtitle = label("VISUAL DEMO  •  v1.0", 10f).apply {
            setTextColor(Color.LTGRAY)
        }
        root.addView(subtitle)
        root.addView(row("AIMBOT", "DEMO ONLY"))
        root.addView(row("ESP / ENEMY ESP", "PREVIEW ONLY"))
        root.addView(row("HEADTRACK", "VISUAL ONLY"))
        root.addView(row("FOV CIRCLE", "ANIMATED"))
        val footer = label("NOT CONNECTED TO FREE FIRE", 9f).apply {
            setTextColor(Color.rgb(255, 105, 115))
        }
        root.addView(footer)

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            270, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }
        root.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + (e.rawX - downX).toInt()
                        p.y = startY + (e.rawY - downY).toInt()
                        wm.updateViewLayout(root, p); return true
                    }
                    MotionEvent.ACTION_UP -> return true
                }
                return false
            }
        })
        panel = root; params = p
        wm.addView(root, p)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(320)
            .setInterpolator(DecelerateInterpolator()).start()
        pulse(root)
    }

    private fun row(name: String, state: String): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bg(Color.rgb(34, 30, 37), Color.rgb(100, 45, 55))
            val a = label(name, 12f).apply { typeface = Typeface.DEFAULT_BOLD }
            val b = label(state, 9f).apply { setTextColor(Color.rgb(255, 110, 120)) }
            addView(a, LinearLayout.LayoutParams(0, -2, 1f))
            addView(b)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, 7, 0, 0)
            layoutParams = lp
        }

    private fun pulse(v: View) {
        val anim = ValueAnimator.ofFloat(0.96f, 1f).apply {
            duration = 950; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { val s = it.animatedValue as Float; v.scaleX = s; v.scaleY = s }
        }
        anim.start()
    }

    private fun togglePanel() {
        val v = panel ?: return
        if (expanded) {
            v.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).setDuration(180)
                .withEndAction { stopSelf() }.start()
        } else stopSelf()
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
